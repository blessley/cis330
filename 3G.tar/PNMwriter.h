#ifndef PNM_WRITER_H
#define PNM_WRITER_H

#include <sink.h>

class PNMwriter : public Sink
{
  public:
    void           Write(const char *);
};

#endif
