#include <image.h>
#include <sink.h>
#include <stdlib.h>
Sink::Sink(void){
	im1 = NULL;
	im2 = NULL;
}
